# -*- coding: utf-8 -*-
"""
Created on Fri Jun 30 15:50:43 2017
Updated on Nov 17 2017

@author: Thuy Pham
 this python code is developed from algorithms for SUMIMO
in the paper "T. M. Pham, R. Farrell, and L.-N. Tran,” Revisiting the MIMO Capacity 
with Per-antenna Power Constraint: Fixed-point Iteration and Alternating Optimization”, under review"
"""


import numpy as np
import scipy.linalg as la
from numpy.linalg import inv

#Algorithm 1, fixed point
def Alg1_fp(H, er, P, nt, nr):
    #initilize
    i = 0
    delt = 1. + er
    G, R = la.qr(H)
    r = np.linalg.matrix_rank(R)
    sz = R.shape
    LD = np.eye(sz[1])
    LD_i = LD
    while np.absolute(delt) > er:
        #fixed waterfilling
        U,e,V = la.svd(np.dot(R,np.diag(np.power(np.diag(LD),-0.5))))
        E = np.zeros((sz[1],sz[1]),dtype=complex)
        e_tmp = 1-np.power(e,-2)
        e_tmp[e_tmp<0] = 0
        E[:r,:r]=np.diag(e_tmp)
        W = np.dot(((V.conj()).T),np.dot(np.eye(sz[1])-E,V))
        S = LD_i - np.dot(np.power(LD_i,0.5),np.dot(W,np.power(LD_i,0.5)))
        delt = np.absolute(np.trace(np.dot(LD,S-P)))

       # update
        LD_i = P + np.real(np.dot(np.diag(np.diag(W)),LD_i))
        LD = np.diag(np.real(np.power(np.diag(LD_i),-1.0)))
        i = i + 1
    return S

#Algorithm 2, alternating optimization
def Alg2_ao(H, er, P, nt, nr):
    #initialize
    i = 0
    delt = 1. + er
    G, R = la.qr(H)
    r = np.linalg.matrix_rank(R)
    sz = R.shape
    LD = np.eye(sz[1])
    obj_temp = 1.
    obj = 1.
    while np.absolute(delt) > er:
        #find uplink covariance
        U,e,V = la.svd(np.dot(R,np.diag(np.power(np.diag(LD),-0.5))),full_matrices=False)
        e_temp = np.power(e,2)
        e_sort = np.power(e_temp,-1) #sort descending order by default
        mu = 0.
        for c in range(r,0,-1):
            mu = (np.sum(e_sort[:c]) + np.sum(P))/c
            if (mu-e_sort[c-1] > 0) :
                break
        E = np.zeros((r,r),dtype=complex)
        E=np.diag(mu - np.power(e_temp,-1))
        E[E<0] = 0
        U1 = np.dot(G,U)
        Sb = np.dot(U1,np.dot(E,(U1.conj()).T))
        obj_temp = obj
        sign1,obj1 = np.linalg.slogdet(LD + np.dot(((H.conj()).T),np.dot(Sb,H)))
        sign2,obj2 = np.linalg.slogdet(LD)
        if (i>0) :
            obj = sign1*obj1-sign2*obj2
            delt = np.absolute(obj-obj_temp)
        
        
        #find noise covariance
        b = np.diag(inv(LD + np.dot(((H.conj()).T),np.dot(Sb,H))))
        delt1 = 1.
        gm0 = 0.001
        gm = gm0
        while delt1 > er:
            gm0 = gm
            f0 = np.sum(np.power(gm0 +np.multiply(b,np.power(np.diag(P),-1)) ,-1))-np.sum(P)
            fd = -np.sum(np.power(gm0 +np.multiply(b,np.power(np.diag(P),-1)) ,-2))
            gm = gm0-f0/fd
            delt1 = np.absolute(gm-gm0)
        gm = np.max(gm,0)
        q = np.power(b +gm*np.diag(P) ,-1)
        LD = np.diag(q)
        i = i + 1
    S = np.dot(np.diag(np.power(q,-0.5)),np.dot((V.conj()).T,np.dot((U1.conj()).T,np.dot(Sb,np.dot(U1,np.dot(V,np.diag(np.power(q,-0.5))))))))
    return S

#create scenario    
mu, sigma = 0, 1 # mean and standard deviation
nt = 4;
nr = 2;
Pt = 1;
H = np.random.normal(mu, sigma, (nr,nt)) + 1j*np.random.normal(mu, sigma, (nr,nt))
P = np.diag(Pt/nt*np.ones(nt))
er = np.power(10.,-6)

#print parameters of the scenario
print("No. of transmit antennas: ", nt)
print("No. of receive antennas: ", nr)
print("Per-antenna power constraint: ")
print(P)

#print values of Algorithm 1
S1 = np.round(Alg1_fp(H,er,P, nt, nr),decimals=3)
sign1,C1=np.real(np.round(np.linalg.slogdet(np.eye(nr) + np.dot((H),np.dot(S1,(H.conj()).T))),3))
print("\nComputed by Algorithm 1") 
print("CMIMO: ",C1)
print("Covariance matrix") 
print(S1)
        
#print values of Algorithm 2
S2 = np.round(Alg2_ao(H,er,P, nt, nr),decimals=3)      
sign2,C2=np.real(np.round(np.linalg.slogdet(np.eye(nr) + np.dot((H),np.dot(S2,(H.conj()).T))),3))
print("\n Computed by Algorithm 2") 
print("CMIMO: ",C2) 
print("Covariance matrix") 
print(S2)

